document.addEventListener('DOMContentLoaded', ()=>{

    const wishBtn = document.getElementById("wishBtn")
    const goWishlistBtn = document.getElementById("goWishlistBtn")
    const backBtn = document.getElementById("backButton")
    const hOne = document.getElementById("testHeadOne")
    const productImg = document.getElementById("testImg")
    const wishlistItems = document.getElementById("wishlistItems")

    let wishlist = []

    let saved = localStorage.getItem("wishlist")
    if(saved){
        try{
            wishlist = JSON.parse(saved)
        }catch(e){
            wishlist = []
        }
    }

    function renderWishlist(){
        if(hOne && productImg){
            hOne.textContent = "wishlist size : " + wishlist.length
        }else if(hOne){
            hOne.textContent = "my wishlist (" + wishlist.length + ")"
        }

        if(!wishlistItems) return

        wishlistItems.innerHTML = ""

        for(let i = 0 ; i < wishlist.length ; i++){
            let item = wishlist[i]

            let box = document.createElement("div")
            box.className = "wishItem"

            let img = document.createElement("img")
            img.src = item.img
            img.alt = "wishlist item " + (i+1)
            img.style.width = "150px"

            let txt = document.createElement("p")
            txt.textContent = "item " + (i+1)

            box.appendChild(img)
            box.appendChild(txt)

            wishlistItems.appendChild(box)
        }
    }

    renderWishlist()

    if(wishBtn){
        wishBtn.addEventListener("click", ()=>{
            let item = {
                img : productImg ? productImg.src : "",
                time : Date.now()
            }

            wishlist.push(item)
            localStorage.setItem("wishlist", JSON.stringify(wishlist))

            renderWishlist()

            fetch("/wishlist",{
                method : "POST",
                headers : {
                    "Content-Type" : "application/json"
                },
                body : JSON.stringify(item)
            })
            .then(res => res.text())
            .then(txt => {
                console.log("server:", txt)
            })
            .catch(err => {
                console.log("error:", err)
            })
        })
    }

    if(goWishlistBtn){
        goWishlistBtn.addEventListener("click", ()=>{
            window.location.href = "/wishlist"
        })
    }

    if(backBtn){
        backBtn.addEventListener("click", ()=>{
            window.location.href = "/"
        })
    }

})
