const express = require('express')
const path = require('path')
const app = express()
const port = 3000

app.use(express.static(__dirname))
app.use(express.json())

app.get('/', (req,res)=>{
    res.sendFile(path.join(__dirname,'index.html'))
})

app.get('/wishlist', (req,res)=>{
    res.sendFile(path.join(__dirname,'wishlist.html'))
})

app.post('/wishlist', (req,res)=>{
    console.log('wishlist item:')
    console.log(req.body)
    res.send('ok')
})

app.get('/api/data', (req,res)=>{
    res.sendFile(path.join(__dirname,'data.json'))
})

app.listen(port, ()=>{
    console.log(`server run at http://localhost:${port}`)
})
